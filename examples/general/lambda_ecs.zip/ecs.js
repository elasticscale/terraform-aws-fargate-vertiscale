"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getRunParameters = exports.runTask = exports.getTaskDetails = void 0;
const client_ecs_1 = require("@aws-sdk/client-ecs");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const getTaskDetails = async (event) => {
    const client = new client_ecs_1.ECSClient({});
    const input = {
        cluster: event['detail']['clusterArn'],
        tasks: [event['detail']['taskArn']],
    };
    const command = new client_ecs_1.DescribeTasksCommand(input);
    const data = await client.send(command);
    if (!data['tasks']) {
        return false;
    }
    return data['tasks'][0] ?? false;
};
exports.getTaskDetails = getTaskDetails;
const runTask = async (task, newCpu, newMemory) => {
    const parameters = await (0, exports.getRunParameters)(task['taskArn']);
    if (!parameters['overrides']) {
        parameters['overrides'] = {};
    }
    parameters['overrides']['cpu'] = newCpu.toString();
    parameters['overrides']['memory'] = newMemory.toString();
    const client = new client_ecs_1.ECSClient({});
    const command = new client_ecs_1.RunTaskCommand(parameters);
    const response = await client.send(command);
    if (!response['tasks']) {
        console.error(response);
        throw new Error('Failed to start task(s)');
    }
    for (const taskResponse of response['tasks']) {
        console.log('started task ' + taskResponse['taskArn']);
    }
    await deleteItem(task['taskArn']);
};
exports.runTask = runTask;
const getRunParameters = async (taskArn) => {
    const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(new client_dynamodb_1.DynamoDBClient({}));
    const command = new lib_dynamodb_1.GetCommand({
        TableName: process.env.DYNAMODB_TABLE,
        Key: {
            taskArn: taskArn,
        },
    });
    const response = await docClient.send(command);
    if (!response.Item) {
        throw new Error('No parameters found for task ' + taskArn);
    }
    return response.Item;
};
exports.getRunParameters = getRunParameters;
const deleteItem = async (taskArn) => {
    const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(new client_dynamodb_1.DynamoDBClient({}));
    const command = new lib_dynamodb_1.DeleteCommand({
        TableName: process.env.DYNAMODB_TABLE,
        Key: {
            taskArn: taskArn,
        },
    });
    await docClient.send(command);
};
