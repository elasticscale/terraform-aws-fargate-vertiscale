"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const ecs_1 = require("./ecs");
const memory_1 = require("./memory");
const handler = async (event) => {
    const taskDetails = await (0, ecs_1.getTaskDetails)(event);
    if (!taskDetails) {
        console.log(event['detail']['taskArn'] + ' could not be found via the ECS API');
        return false;
    }
    const runParameters = await (0, ecs_1.getRunParameters)(taskDetails['taskArn']);
    if (!runParameters) {
        console.log(event['detail']['taskArn'] +
            ' could not find the runParameters in DynamoDB');
        return false;
    }
    const newCpuMemory = (0, memory_1.determineNewCpuMemory)(taskDetails['platformFamily'], taskDetails['cpu'], taskDetails['memory']);
    if (!newCpuMemory) {
        console.log(event['detail']['taskArn'] + ' new memory could not be decided');
        return false;
    }
    if (newCpuMemory['memory'] > parseInt(process.env.MAXMEMORY)) {
        console.log(event['detail']['taskArn'] +
            ' new memory limit of ' +
            newCpuMemory['memory'] +
            ' would exceed max set of ' +
            process.env.MAXMEMORY);
        return false;
    }
    try {
        await (0, ecs_1.runTask)(taskDetails, newCpuMemory['cpu'], newCpuMemory['memory']);
    }
    catch (error) {
        console.log('Could not start task: ' + error.message);
        return false;
    }
    console.log('tasks have been started');
};
exports.handler = handler;
