"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const ecs_1 = require("./ecs");
const memory_1 = require("./memory");
const handler = async (event) => {
    console.log(JSON.stringify(event));
    const taskDetails = await (0, ecs_1.getTaskDetails)(event);
    if (!taskDetails) {
        return event['detail']['taskArn'] + ' could not be found via the ECS API';
    }
    const runParameters = await (0, ecs_1.getRunParameters)(taskDetails['taskArn']);
    if (!runParameters) {
        return (event['detail']['taskArn'] +
            ' could not find the runParameters in DynamoDB');
    }
    console.log(taskDetails);
    const newCpuMemory = (0, memory_1.determineNewCpuMemory)(taskDetails);
    if (!newCpuMemory) {
        return event['detail']['taskArn'] + ' new memory could not be decided';
    }
    if (newCpuMemory['memory'] > parseInt(process.env.MAXMEMORY)) {
        return (event['detail']['taskArn'] +
            ' new memory limit of ' +
            newCpuMemory['memory'] +
            ' would exceed max set of ' +
            process.env.MAXMEMORY);
    }
    await (0, ecs_1.runTask)(taskDetails, newCpuMemory['cpu'], newCpuMemory['memory']);
    return 'tasks have been started';
};
exports.handler = handler;
