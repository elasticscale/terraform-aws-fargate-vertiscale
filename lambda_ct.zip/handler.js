"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const handler = async (event) => {
    const tasks = [];
    if (!event['detail']['responseElements']['tasks'] ||
        event['detail']['responseElements']['tasks'].length === 0) {
        throw new Error('No tasks found in responseElements');
    }
    for (const task of event['detail']['responseElements']['tasks']) {
        try {
            await storeInvocationDetails(task['taskArn'], event['detail']['requestParameters']);
            tasks.push(task['taskArn']);
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            console.error(`Task ${task['taskArn']} could not be saved in dynamodb: ${errorMessage}`);
        }
    }
    console.log('Logged the following tasks:', tasks);
};
exports.handler = handler;
const storeInvocationDetails = async (taskArn, data) => {
    const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(new client_dynamodb_1.DynamoDBClient({}));
    const input = {
        TableName: process.env.DYNAMODB_TABLE,
        Item: {
            taskArn: taskArn,
            ...data,
            expires: Math.floor(Date.now() / 1000) +
                parseInt(process.env.TTL_EXPIRES),
        },
    };
    const command = new lib_dynamodb_1.PutCommand(input);
    await docClient.send(command);
};
